#include "types.h"
#include "stat.h"
#include "user.h"

//calls crsp for ps
int
main(void)
{
  //Runs the process 
  crsp();
  exit();
}