#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"

//scheduler uses this as well
//creates spinlock struct and proc struct as used in scheduler
struct 
{
  struct spinlock lock;
  struct proc proc[NPROC];
} ptable;

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

//return the year that Xv6 was released
int
sys_getyear(void)
{
  cprintf("Xv6 was released in the year 1975\n");
  return 0;
}

/*Loop through p table and get what processes are running, count for how many processes are running, 
and how many processes are sleeping
Utilization of spinlock and proc*/
int
sys_crsp(void)
{
  struct proc *p;
  acquire(&ptable.lock);

  cprintf("name\tpid\tstate\n\n");
  cprintf("------------------------\n");

  //go through p table
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    {
      switch (p->state)
	{

  //for every running process
	case RUNNING:
	  cprintf("%s\t%d\tRUNNING\n", p->name, p->pid);
	  break;

  //for every sleeping process
	case SLEEPING:
	  cprintf("%s\t%d\tSLEEPING\n", p->name, p->pid);
	  break;
	default:
	  break;
	}
    }
  release(&ptable.lock);
  return 0;
}

//returns the fact that OW2 aint good
int
sys_isOW2good(void)
{
  cprintf("No, it is garbage.\n Average user score: ");
  return 0;
}
