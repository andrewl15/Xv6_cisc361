#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
    printf(1, "Unix V6 was released in the year %d\n", getyear());
    exit();
}